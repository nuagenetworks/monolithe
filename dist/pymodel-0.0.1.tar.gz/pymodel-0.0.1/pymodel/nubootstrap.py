# -*- coding: utf-8 -*-
from .autogenerates import NUBootstrap as AutoGenerate


class NUBootstrap(AutoGenerate):
    """ Represents a Bootstrap object """

    pass
