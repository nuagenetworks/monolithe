# -*- coding: utf-8 -*-
from .autogenerates import NUVPNConnect as AutoGenerate


class NUVPNConnect(AutoGenerate):
    """ Represents a VPNConnect object """

    pass
