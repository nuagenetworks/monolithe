# -*- coding: utf-8 -*-
from .autogenerates import NUMultiCastRange as AutoGenerate


class NUMultiCastRange(AutoGenerate):
    """ Represents a MultiCastRange object """

    pass
