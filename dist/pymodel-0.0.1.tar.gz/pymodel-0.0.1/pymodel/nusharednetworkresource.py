# -*- coding: utf-8 -*-
from .autogenerates import NUSharedNetworkResource as AutoGenerate


class NUSharedNetworkResource(AutoGenerate):
    """ Represents a SharedNetworkResource object """

    pass
