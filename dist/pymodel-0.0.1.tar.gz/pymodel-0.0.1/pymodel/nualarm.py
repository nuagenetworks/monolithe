# -*- coding: utf-8 -*-
from .autogenerates import NUAlarm as AutoGenerate


class NUAlarm(AutoGenerate):
    """ Represents a Alarm object """

    pass
