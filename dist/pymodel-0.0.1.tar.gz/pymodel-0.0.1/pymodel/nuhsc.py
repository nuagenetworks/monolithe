# -*- coding: utf-8 -*-
from .autogenerates import NUHSC as AutoGenerate


class NUHSC(AutoGenerate):
    """ Represents a HSC object """

    pass
