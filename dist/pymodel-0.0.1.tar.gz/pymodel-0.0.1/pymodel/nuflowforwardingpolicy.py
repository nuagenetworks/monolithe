# -*- coding: utf-8 -*-
from .autogenerates import NUFlowForwardingPolicy as AutoGenerate


class NUFlowForwardingPolicy(AutoGenerate):
    """ Represents a FlowForwardingPolicy object """

    pass
