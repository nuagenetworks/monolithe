# -*- coding: utf-8 -*-
from .autogenerates import NUVPortTagTemplate as AutoGenerate


class NUVPortTagTemplate(AutoGenerate):
    """ Represents a VPortTagTemplate object """

    pass
