# -*- coding: utf-8 -*-
from .autogenerates import NUVPortMirror as AutoGenerate


class NUVPortMirror(AutoGenerate):
    """ Represents a VPortMirror object """

    pass
