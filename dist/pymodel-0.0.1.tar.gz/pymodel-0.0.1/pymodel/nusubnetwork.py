# -*- coding: utf-8 -*-
from .autogenerates import NUSubNetwork as AutoGenerate


class NUSubNetwork(AutoGenerate):
    """ Represents a SubNetwork object """

    pass
