# -*- coding: utf-8 -*-
from .autogenerates import NUPermittedAction as AutoGenerate


class NUPermittedAction(AutoGenerate):
    """ Represents a PermittedAction object """

    pass
