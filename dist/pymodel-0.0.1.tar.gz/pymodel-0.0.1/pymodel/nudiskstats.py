# -*- coding: utf-8 -*-
from .autogenerates import NUDiskStats as AutoGenerate


class NUDiskStats(AutoGenerate):
    """ Represents a DiskStats object """

    pass
