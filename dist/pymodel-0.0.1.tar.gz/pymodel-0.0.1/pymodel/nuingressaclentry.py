# -*- coding: utf-8 -*-
from .autogenerates import NUIngressACLEntry as AutoGenerate


class NUIngressACLEntry(AutoGenerate):
    """ Represents a IngressACLEntry object """

    pass
