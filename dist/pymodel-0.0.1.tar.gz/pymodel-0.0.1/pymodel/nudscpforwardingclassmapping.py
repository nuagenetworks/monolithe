# -*- coding: utf-8 -*-
from .autogenerates import NUDSCPForwardingClassMapping as AutoGenerate


class NUDSCPForwardingClassMapping(AutoGenerate):
    """ Represents a DSCPForwardingClassMapping object """

    pass
