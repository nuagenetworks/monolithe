# -*- coding: utf-8 -*-
from .autogenerates import NUSubNetworkTemplate as AutoGenerate


class NUSubNetworkTemplate(AutoGenerate):
    """ Represents a SubNetworkTemplate object """

    pass
