# -*- coding: utf-8 -*-
from .autogenerates import NUPublicNetworkMacro as AutoGenerate


class NUPublicNetworkMacro(AutoGenerate):
    """ Represents a PublicNetworkMacro object """

    pass
