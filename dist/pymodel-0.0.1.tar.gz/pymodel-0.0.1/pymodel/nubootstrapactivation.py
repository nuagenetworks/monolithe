# -*- coding: utf-8 -*-
from .autogenerates import NUBootstrapActivation as AutoGenerate


class NUBootstrapActivation(AutoGenerate):
    """ Represents a BootstrapActivation object """

    pass
