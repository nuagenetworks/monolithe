# -*- coding: utf-8 -*-
from .autogenerates import NUFlow as AutoGenerate


class NUFlow(AutoGenerate):
    """ Represents a Flow object """

    pass
