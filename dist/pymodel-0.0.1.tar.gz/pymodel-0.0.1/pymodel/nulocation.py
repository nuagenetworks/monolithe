# -*- coding: utf-8 -*-
from .autogenerates import NULocation as AutoGenerate


class NULocation(AutoGenerate):
    """ Represents a Location object """

    pass
