# -*- coding: utf-8 -*-
from .autogenerates import NUVirtualMachine as AutoGenerate


class NUVirtualMachine(AutoGenerate):
    """ Represents a VirtualMachine object """

    pass
