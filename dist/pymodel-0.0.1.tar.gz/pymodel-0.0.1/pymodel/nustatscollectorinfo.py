# -*- coding: utf-8 -*-
from .autogenerates import NUStatsCollectorInfo as AutoGenerate


class NUStatsCollectorInfo(AutoGenerate):
    """ Represents a StatsCollectorInfo object """

    pass
