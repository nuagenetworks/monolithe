# -*- coding: utf-8 -*-
from .autogenerates import NUVSDComponent as AutoGenerate


class NUVSDComponent(AutoGenerate):
    """ Represents a VSDComponent object """

    pass
