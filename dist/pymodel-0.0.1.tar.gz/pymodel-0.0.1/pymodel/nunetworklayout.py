# -*- coding: utf-8 -*-
from .autogenerates import NUNetworkLayout as AutoGenerate


class NUNetworkLayout(AutoGenerate):
    """ Represents a NetworkLayout object """

    pass
