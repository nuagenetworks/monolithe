# -*- coding: utf-8 -*-
from .autogenerates import NUIngressAdvancedForwarding as AutoGenerate


class NUIngressAdvancedForwarding(AutoGenerate):
    """ Represents a IngressAdvancedForwarding object """

    pass
