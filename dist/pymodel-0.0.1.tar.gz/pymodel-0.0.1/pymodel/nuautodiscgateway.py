# -*- coding: utf-8 -*-
from .autogenerates import NUAutoDiscGateway as AutoGenerate


class NUAutoDiscGateway(AutoGenerate):
    """ Represents a AutoDiscGateway object """

    pass
