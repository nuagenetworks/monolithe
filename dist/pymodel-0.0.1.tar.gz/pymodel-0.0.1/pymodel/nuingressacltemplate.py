# -*- coding: utf-8 -*-
from .autogenerates import NUIngressACLTemplate as AutoGenerate


class NUIngressACLTemplate(AutoGenerate):
    """ Represents a IngressACLTemplate object """

    pass
