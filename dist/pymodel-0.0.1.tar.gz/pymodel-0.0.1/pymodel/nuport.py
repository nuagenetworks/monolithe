# -*- coding: utf-8 -*-
from .autogenerates import NUPort as AutoGenerate


class NUPort(AutoGenerate):
    """ Represents a Port object """

    pass
