# -*- coding: utf-8 -*-
from .autogenerates import NUStaticRoute as AutoGenerate


class NUStaticRoute(AutoGenerate):
    """ Represents a StaticRoute object """

    pass
