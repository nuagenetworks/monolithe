# -*- coding: utf-8 -*-
from .autogenerates import NUEnterpriseNetworkMacro as AutoGenerate


class NUEnterpriseNetworkMacro(AutoGenerate):
    """ Represents a EnterpriseNetworkMacro object """

    pass
