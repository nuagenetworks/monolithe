# -*- coding: utf-8 -*-
from .autogenerates import NUZone as AutoGenerate


class NUZone(AutoGenerate):
    """ Represents a Zone object """

    pass
