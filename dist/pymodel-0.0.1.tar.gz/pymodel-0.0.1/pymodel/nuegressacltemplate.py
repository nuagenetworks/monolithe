# -*- coding: utf-8 -*-
from .autogenerates import NUEgressACLTemplate as AutoGenerate


class NUEgressACLTemplate(AutoGenerate):
    """ Represents a EgressACLTemplate object """

    pass
