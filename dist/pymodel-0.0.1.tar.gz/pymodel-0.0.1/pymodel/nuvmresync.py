# -*- coding: utf-8 -*-
from .autogenerates import NUVMResync as AutoGenerate


class NUVMResync(AutoGenerate):
    """ Represents a VMResync object """

    pass
