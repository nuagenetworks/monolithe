# -*- coding: utf-8 -*-
from .autogenerates import NUZoneTemplate as AutoGenerate


class NUZoneTemplate(AutoGenerate):
    """ Represents a ZoneTemplate object """

    pass
