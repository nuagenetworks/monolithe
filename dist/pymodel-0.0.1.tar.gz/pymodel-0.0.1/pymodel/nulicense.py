# -*- coding: utf-8 -*-
from .autogenerates import NULicense as AutoGenerate


class NULicense(AutoGenerate):
    """ Represents a License object """

    pass
