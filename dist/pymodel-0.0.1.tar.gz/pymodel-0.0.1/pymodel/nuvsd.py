# -*- coding: utf-8 -*-
from .autogenerates import NUVSD as AutoGenerate


class NUVSD(AutoGenerate):
    """ Represents a VSD object """

    pass
