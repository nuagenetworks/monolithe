# -*- coding: utf-8 -*-
from .autogenerates import NUMetadata as AutoGenerate


class NUMetadata(AutoGenerate):
    """ Represents a Metadata object """

    pass
