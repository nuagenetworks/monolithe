# -*- coding: utf-8 -*-
from .autogenerates import NUInfrastructurePortProfile as AutoGenerate


class NUInfrastructurePortProfile(AutoGenerate):
    """ Represents a InfrastructurePortProfile object """

    pass
