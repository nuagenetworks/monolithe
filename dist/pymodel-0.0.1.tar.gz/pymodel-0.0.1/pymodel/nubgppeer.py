# -*- coding: utf-8 -*-
from .autogenerates import NUBGPPeer as AutoGenerate


class NUBGPPeer(AutoGenerate):
    """ Represents a BGPPeer object """

    pass
