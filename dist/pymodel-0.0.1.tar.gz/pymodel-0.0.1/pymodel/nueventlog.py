# -*- coding: utf-8 -*-
from .autogenerates import NUEventLog as AutoGenerate


class NUEventLog(AutoGenerate):
    """ Represents a EventLog object """

    pass
