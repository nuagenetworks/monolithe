# -*- coding: utf-8 -*-
from .autogenerates import NUVPortGatewayResponse as AutoGenerate


class NUVPortGatewayResponse(AutoGenerate):
    """ Represents a VPortGatewayResponse object """

    pass
