# -*- coding: utf-8 -*-
from .autogenerates import NUFloatingIp as AutoGenerate


class NUFloatingIp(AutoGenerate):
    """ Represents a FloatingIp object """

    pass
