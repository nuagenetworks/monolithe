# -*- coding: utf-8 -*-
from .autogenerates import NUDSCPForwardingClassTable as AutoGenerate


class NUDSCPForwardingClassTable(AutoGenerate):
    """ Represents a DSCPForwardingClassTable object """

    pass
