# -*- coding: utf-8 -*-
from .autogenerates import NUMultiNICVPort as AutoGenerate


class NUMultiNICVPort(AutoGenerate):
    """ Represents a MultiNICVPort object """

    pass
