# -*- coding: utf-8 -*-
from .autogenerates import NUPortTemplate as AutoGenerate


class NUPortTemplate(AutoGenerate):
    """ Represents a PortTemplate object """

    pass
