# -*- coding: utf-8 -*-
from .autogenerates import NUIngressAdvancedForwardingEntry as AutoGenerate


class NUIngressAdvancedForwardingEntry(AutoGenerate):
    """ Represents a IngressAdvancedForwardingEntry object """

    pass
