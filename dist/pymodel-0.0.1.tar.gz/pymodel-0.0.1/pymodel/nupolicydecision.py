# -*- coding: utf-8 -*-
from .autogenerates import NUPolicyDecision as AutoGenerate


class NUPolicyDecision(AutoGenerate):
    """ Represents a PolicyDecision object """

    pass
