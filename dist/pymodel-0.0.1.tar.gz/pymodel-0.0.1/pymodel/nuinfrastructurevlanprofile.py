# -*- coding: utf-8 -*-
from .autogenerates import NUInfrastructureVlanProfile as AutoGenerate


class NUInfrastructureVlanProfile(AutoGenerate):
    """ Represents a InfrastructureVlanProfile object """

    pass
