# -*- coding: utf-8 -*-
from .autogenerates import NUVMInterface as AutoGenerate


class NUVMInterface(AutoGenerate):
    """ Represents a VMInterface object """

    pass
