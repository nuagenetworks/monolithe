# -*- coding: utf-8 -*-
from .autogenerates import NUEnterprisePermission as AutoGenerate


class NUEnterprisePermission(AutoGenerate):
    """ Represents a EnterprisePermission object """

    pass
