# -*- coding: utf-8 -*-
from .autogenerates import NUAddressRange as AutoGenerate


class NUAddressRange(AutoGenerate):
    """ Represents a AddressRange object """

    pass
