# -*- coding: utf-8 -*-
from .autogenerates import NUHostInterface as AutoGenerate


class NUHostInterface(AutoGenerate):
    """ Represents a HostInterface object """

    pass
