# -*- coding: utf-8 -*-
from .autogenerates import NUPortStatus as AutoGenerate


class NUPortStatus(AutoGenerate):
    """ Represents a PortStatus object """

    pass
