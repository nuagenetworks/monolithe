# -*- coding: utf-8 -*-
from .autogenerates import NUJob as AutoGenerate


class NUJob(AutoGenerate):
    """ Represents a Job object """

    pass
