# -*- coding: utf-8 -*-
from .autogenerates import NUMultiCastChannelMap as AutoGenerate


class NUMultiCastChannelMap(AutoGenerate):
    """ Represents a MultiCastChannelMap object """

    pass
