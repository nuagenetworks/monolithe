# -*- coding: utf-8 -*-
from .autogenerates import NUIPBinding as AutoGenerate


class NUIPBinding(AutoGenerate):
    """ Represents a IPBinding object """

    pass
