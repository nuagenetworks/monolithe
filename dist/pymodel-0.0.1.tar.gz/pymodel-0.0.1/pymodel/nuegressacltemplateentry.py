# -*- coding: utf-8 -*-
from .autogenerates import NUEgressACLTemplateEntry as AutoGenerate


class NUEgressACLTemplateEntry(AutoGenerate):
    """ Represents a EgressACLTemplateEntry object """

    pass
