# -*- coding: utf-8 -*-
from .autogenerates import NULDAPConfiguration as AutoGenerate


class NULDAPConfiguration(AutoGenerate):
    """ Represents a LDAPConfiguration object """

    pass
