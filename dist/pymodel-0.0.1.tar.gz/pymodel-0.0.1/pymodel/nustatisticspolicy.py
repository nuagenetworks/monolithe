# -*- coding: utf-8 -*-
from .autogenerates import NUStatisticsPolicy as AutoGenerate


class NUStatisticsPolicy(AutoGenerate):
    """ Represents a StatisticsPolicy object """

    pass
