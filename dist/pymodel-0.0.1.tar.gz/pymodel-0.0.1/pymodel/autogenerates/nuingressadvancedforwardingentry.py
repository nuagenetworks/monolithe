# -*- coding: utf-8 -*-


from restnuage import NURESTObject


class NUIngressAdvancedForwardingEntry(NURESTObject):
    """ Represents a IngressAdvancedForwardingEntry object """

    def __init__(self):
        """ Initializing object """

        super(NUIngressAdvancedForwardingEntry, self).__init__()

        # Read/Write Attributes
        
        

        # Fetchers
        

    @classmethod
    def get_remote_name(cls):
        """ Remote name that will be used to generates URI """

        return u""

    # REST methods
    