# -*- coding: utf-8 -*-
from .autogenerates import NUDHCPOption as AutoGenerate


class NUDHCPOption(AutoGenerate):
    """ Represents a DHCPOption object """

    pass
