# -*- coding: utf-8 -*-
from .autogenerates import NUVSC as AutoGenerate


class NUVSC(AutoGenerate):
    """ Represents a VSC object """

    pass
