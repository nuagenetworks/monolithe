# -*- coding: utf-8 -*-
from .autogenerates import NUVlanTemplate as AutoGenerate


class NUVlanTemplate(AutoGenerate):
    """ Represents a VlanTemplate object """

    pass
