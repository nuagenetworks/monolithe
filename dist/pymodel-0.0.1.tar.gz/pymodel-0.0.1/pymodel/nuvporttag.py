# -*- coding: utf-8 -*-
from .autogenerates import NUVPortTag as AutoGenerate


class NUVPortTag(AutoGenerate):
    """ Represents a VPortTag object """

    pass
