# -*- coding: utf-8 -*-
from .autogenerates import NUTCA as AutoGenerate


class NUTCA(AutoGenerate):
    """ Represents a TCA object """

    pass
