# -*- coding: utf-8 -*-
from .autogenerates import NUPolicyGroup as AutoGenerate


class NUPolicyGroup(AutoGenerate):
    """ Represents a PolicyGroup object """

    pass
