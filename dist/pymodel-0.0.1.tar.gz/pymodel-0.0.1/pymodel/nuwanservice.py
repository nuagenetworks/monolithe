# -*- coding: utf-8 -*-
from .autogenerates import NUWANService as AutoGenerate


class NUWANService(AutoGenerate):
    """ Represents a WANService object """

    pass
