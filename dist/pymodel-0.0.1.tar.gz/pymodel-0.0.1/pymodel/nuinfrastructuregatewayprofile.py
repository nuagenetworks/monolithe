# -*- coding: utf-8 -*-
from .autogenerates import NUInfrastructureGatewayProfile as AutoGenerate


class NUInfrastructureGatewayProfile(AutoGenerate):
    """ Represents a InfrastructureGatewayProfile object """

    pass
