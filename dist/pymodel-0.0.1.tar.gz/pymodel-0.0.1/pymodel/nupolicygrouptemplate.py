# -*- coding: utf-8 -*-
from .autogenerates import NUPolicyGroupTemplate as AutoGenerate


class NUPolicyGroupTemplate(AutoGenerate):
    """ Represents a PolicyGroupTemplate object """

    pass
