# -*- coding: utf-8 -*-
from .autogenerates import NUVRS as AutoGenerate


class NUVRS(AutoGenerate):
    """ Represents a VRS object """

    pass
