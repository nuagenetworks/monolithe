# -*- coding: utf-8 -*-
from .autogenerates import NUEnterpriseProfile as AutoGenerate


class NUEnterpriseProfile(AutoGenerate):
    """ Represents a EnterpriseProfile object """

    pass
