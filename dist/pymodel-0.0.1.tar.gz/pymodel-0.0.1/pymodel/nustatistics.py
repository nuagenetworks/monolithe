# -*- coding: utf-8 -*-
from .autogenerates import NUStatistics as AutoGenerate


class NUStatistics(AutoGenerate):
    """ Represents a Statistics object """

    pass
