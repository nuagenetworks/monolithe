# -*- coding: utf-8 -*-
from .autogenerates import NUVirtualIP as AutoGenerate


class NUVirtualIP(AutoGenerate):
    """ Represents a VirtualIP object """

    pass
