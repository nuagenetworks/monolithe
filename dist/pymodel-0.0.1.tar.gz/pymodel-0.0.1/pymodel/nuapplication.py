# -*- coding: utf-8 -*-
from .autogenerates import NUApplication as AutoGenerate


class NUApplication(AutoGenerate):
    """ Represents a Application object """

    pass
