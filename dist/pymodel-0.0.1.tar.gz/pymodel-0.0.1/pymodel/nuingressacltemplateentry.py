# -*- coding: utf-8 -*-
from .autogenerates import NUIngressACLTemplateEntry as AutoGenerate


class NUIngressACLTemplateEntry(AutoGenerate):
    """ Represents a IngressACLTemplateEntry object """

    pass
