# -*- coding: utf-8 -*-
from .autogenerates import NUIngressAdvancedForwardingTemplateEntry as AutoGenerate


class NUIngressAdvancedForwardingTemplateEntry(AutoGenerate):
    """ Represents a IngressAdvancedForwardingTemplateEntry object """

    pass
