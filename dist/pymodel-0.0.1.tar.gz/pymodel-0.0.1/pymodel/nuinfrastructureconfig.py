# -*- coding: utf-8 -*-
from .autogenerates import NUInfrastructureConfig as AutoGenerate


class NUInfrastructureConfig(AutoGenerate):
    """ Represents a InfrastructureConfig object """

    pass
