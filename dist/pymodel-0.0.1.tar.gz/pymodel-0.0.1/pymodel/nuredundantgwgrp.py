# -*- coding: utf-8 -*-
from .autogenerates import NURedundantGWGrp as AutoGenerate


class NURedundantGWGrp(AutoGenerate):
    """ Represents a RedundantGWGrp object """

    pass
