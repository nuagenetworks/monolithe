# -*- coding: utf-8 -*-
from .autogenerates import NUVlan as AutoGenerate


class NUVlan(AutoGenerate):
    """ Represents a Vlan object """

    pass
