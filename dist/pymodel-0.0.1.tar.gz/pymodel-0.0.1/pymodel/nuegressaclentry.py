# -*- coding: utf-8 -*-
from .autogenerates import NUEgressACLEntry as AutoGenerate


class NUEgressACLEntry(AutoGenerate):
    """ Represents a EgressACLEntry object """

    pass
