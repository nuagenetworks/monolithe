# -*- coding: utf-8 -*-
from .autogenerates import NUVSP as AutoGenerate


class NUVSP(AutoGenerate):
    """ Represents a VSP object """

    pass
