# -*- coding: utf-8 -*-
from .autogenerates import NUApp as AutoGenerate


class NUApp(AutoGenerate):
    """ Represents a App object """

    pass
