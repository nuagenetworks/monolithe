# -*- coding: utf-8 -*-
from .autogenerates import NUSystemConfig as AutoGenerate


class NUSystemConfig(AutoGenerate):
    """ Represents a SystemConfig object """

    pass
