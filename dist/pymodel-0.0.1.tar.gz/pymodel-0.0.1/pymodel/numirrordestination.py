# -*- coding: utf-8 -*-
from .autogenerates import NUMirrorDestination as AutoGenerate


class NUMirrorDestination(AutoGenerate):
    """ Represents a MirrorDestination object """

    pass
