# -*- coding: utf-8 -*-
from .autogenerates import NUQosPrimitive as AutoGenerate


class NUQosPrimitive(AutoGenerate):
    """ Represents a QosPrimitive object """

    pass
