# -*- coding: utf-8 -*-
from .autogenerates import NUIngressAdvancedForwardingTemplate as AutoGenerate


class NUIngressAdvancedForwardingTemplate(AutoGenerate):
    """ Represents a IngressAdvancedForwardingTemplate object """

    pass
