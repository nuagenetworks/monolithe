# -*- coding: utf-8 -*-
from .autogenerates import NUIngressACL as AutoGenerate


class NUIngressACL(AutoGenerate):
    """ Represents a IngressACL object """

    pass
