# -*- coding: utf-8 -*-
from .autogenerates import NUEgressACL as AutoGenerate


class NUEgressACL(AutoGenerate):
    """ Represents a EgressACL object """

    pass
