# -*- coding: utf-8 -*-
from .autogenerates import NUBridgeInterface as AutoGenerate


class NUBridgeInterface(AutoGenerate):
    """ Represents a BridgeInterface object """

    pass
